#include<iostream>
using namespace std;

int main(){

    int a;
    float b;
    double c;
    char d;
    bool e;

    cout<<"Size of int is: "<<sizeof(a)<<endl;
    cout<<"Size of float is: "<<sizeof(b)<<endl;
    cout<<"Size of double is: "<<sizeof(c)<<endl;
    cout<<"Size of char is: "<<sizeof(d)<<endl;
    cout<<"Size of bool is: "<<sizeof(e)<<endl;

return 0;
}